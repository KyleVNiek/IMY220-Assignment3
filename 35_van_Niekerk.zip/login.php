<?php
	// See all errors and warnings
	error_reporting(E_ALL);
	ini_set('error_reporting', E_ALL);

	// Your database details might be different
	$mysqli = mysqli_connect("localhost", "root", "", "dbUser");

	$email = isset($_POST["email"]) ? $_POST["email"] : false;
	$pass = isset($_POST["pass"]) ? $_POST["pass"] : false;

		if(isset($_FILES["fileToUpload"])&& $_FILES["fileToUpload"]["name"][0]!="")
		{
			$dir = "gallery/";
			$count = count($_FILES["fileToUpload"]['tmp_name']);


			for( $counter= 0; $counter < $count; $counter++)
			{
					$size = $_FILES['fileToUpload']['size'][$counter];
				  /*  $type = $_FILES['fileToUpload']['type'][$counter]; */
					if($size<=1048576)
					{
						$uploadFile = $_FILES["fileToUpload"];

					   $target_file = $dir . basename($uploadFile["name"][$counter]);
						if(move_uploaded_file($uploadFile["tmp_name"][$counter], $target_file))
						{

							$query = "SELECT * FROM tbuser WHERE email = '$email' AND password = '$pass'";
							$res = $mysqli->query($query);
							if($row = mysqli_fetch_array($res))
							{
								$id = $row['user_id'];
								$upQuery = "INSERT INTO  tbgallery (user_id,filename) VALUES ($id,'$target_file') ";
								$exe = $mysqli->query($upQuery);
							}

						}
						else{echo "An error has occured!";}
					}

			}
		}
?>

<!DOCTYPE html>
<html>
<head>
	<title>IMY 220 - Assignment 3</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="style.css" />
	<meta charset="utf-8" />
	<meta name="Kyle" content="Van Niekerk">
	<!-- Replace Name Surname with your name and surname -->
</head>
	<body>
	  <div class="panel panel-default">
		<div class="panel-body">
		<div class="container">
			<?php
				if($email && $pass){
					$query = "SELECT * FROM tbuser WHERE email = '$email' AND password = '$pass'";
					$res = $mysqli->query($query);
					if($row = mysqli_fetch_array($res)){
						$id =  $row['user_id'];
						echo 	"<table class='table table-bordered mt-3' >
									<tr>
										<td><b>Name:</b></td>
										<td>" . $row['name'] . "</td>
									<tr>
									<tr>
										<td><b>Surname:</b></td>
										<td>" . $row['surname'] . "</td>
									<tr>
									<tr>
										<td><b>Email Address:</b></td>
										<td>" . $row['email'] . "</td>
									<tr>

									<tr>
										<td><b>User ID:</b></td>
										<td>" . $row['user_id'] . "</td>
									<tr>
								</table>";

						echo 	"<form action='login.php' method='post' enctype='multipart/form-data'>
									<div class='form-group'>
									<input name='email' value='$email' hidden>
									<input name='pass' value='$pass' hidden>
									<div>

									<!--	<div>
											<form action = login.php>
											<div><h6>
												<label for='textarea1'> Discription: </label>
												  <input type='textarea' name='textarea1' id = 'textarea1' rows='5' cols='40' placeholder= 'Type description here.'>
												  <br></h6>
											</form>
										</div>

										<div>
											<form action = login.php>
												<div><h6>
												<label for='type'><font color='white'> Type: </font></label>
												  <input type='type' id='type' placeholder='Type type here' class = 'form-control' name='type'>
												</div>
											</form>      -->
										</div>
										<div><p></p></divf>

										<div>
											<input type='file' class='form-control' name='fileToUpload[]' id='fileToUpload' multiple='multiple' /><br/>
										</div>
										<input type='submit' class='btn btn-standard' value='Upload New Image' name='submit' />
										</div>

									</div>
								</form>";

							$mysqli = mysqli_connect("localhost", "root", "", "dbUser");

							$filename = implode('', $_FILES['fileToUpload']['name']);

							if (isset($_POST['textarea1'])) {
								$image = htmlentities($_POST['textarea1']);}

							$query = "INSERT INTO tbgallery (filename, image_id, user_id) VALUES ('$filename', '$image', '$user');";

						$query = "SELECT * FROM tbgallery WHERE user_id = $id";  			//
						$res = $mysqli->query($query);										//
						echo "<h3 style='color:white;'><b>Activiy Feed:</b></h3>";			//
						echo "<div class='row gallery'>";								//


						$count =1;
						while($row = mysqli_fetch_array($res))
						{

							echo "<div class='col-5 col-md-6'>
								<div class='card'>";

								echo
								<div class='card-body'>";

								echo "<div class='col-5' >
										<h6><b>Filename: </b>" . $filename ."</font></h6>
									 </div>";

							echo "</div>
								  </div>

								  </div>";

							$count++;

						}
						echo"</div>";
					}

					else{
						echo 	'<div class="alert alert-danger mt-3" role="alert">
									You are not registered
								</div>';
					}
				}
				else{
					echo 	'<div class="alert alert-danger mt-3" role="alert">
								Could not log you in
							</div>';
				}
			?>
		</div>
		</div>
		</div>
	</body>
</html>
